// Types shared between apps/api (enqueues jobs) and apps/worker (consumes
// them) so the job payload contract can never silently drift apart.

export interface MergePdfJobData {
  jobId: string;       // Prisma Job.id — worker updates progress/status on this row
  userId: string;
  fileKeys: string[];  // storage keys, in merge order
}

export interface CompressImageJobData {
  jobId: string;
  userId: string;
  fileKey: string;
  quality: number;     // 1-100
  format?: 'jpeg' | 'png' | 'webp';
}

export type PlanLimits = {
  maxFileSizeMb: number;
  maxFilesPerMonth: number;
  aiCreditsPerMonth: number;
};

export const PLAN_LIMITS: Record<'FREE' | 'PRO' | 'BUSINESS', PlanLimits> = {
  FREE:     { maxFileSizeMb: 10,  maxFilesPerMonth: 15,   aiCreditsPerMonth: 5 },
  PRO:      { maxFileSizeMb: 200, maxFilesPerMonth: 1000, aiCreditsPerMonth: 200 },
  BUSINESS: { maxFileSizeMb: 500, maxFilesPerMonth: 10000, aiCreditsPerMonth: 2000 },
};
