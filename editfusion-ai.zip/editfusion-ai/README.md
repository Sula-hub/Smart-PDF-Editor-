# EditFusion AI

A SaaS document/image editing platform (iLovePDF / Smallpdf / Canva-tools competitor),
built as a pnpm monorepo: **Next.js 15** frontend, **NestJS** API, a standalone
**BullMQ worker** for CPU-heavy processing, **PostgreSQL + Prisma**, **Redis**,
and **R2/S3** storage with automatic file deletion.

## Why this repo looks the way it does

A platform with 60+ processing tools, billing, an admin panel, and AI features is a
multi-quarter build, not a single generated artifact. Rather than hand you thousands
of files of unverifiable boilerplate, this repo gives you:

1. **The real architecture**, wired end-to-end and internally consistent — routing,
   auth, queueing, storage, billing, DB schema all reference each other correctly.
2. **Two fully working tools implemented top-to-bottom** — Merge PDF and Compress
   Image — covering the two hardest architectural problems (multi-file PDF ops,
   binary image processing) so every remaining tool is a copy-paste-and-adjust job,
   not a new pattern.
3. **The complete database schema** for the entire product (all 60+ tool enums,
   subscriptions, usage limits, admin, API keys, coupons) — the data layer doesn't
   need to grow as you add tools.
4. **A precise roadmap** (below) for extending to full parity, in the order that
   minimizes rework.

## Monorepo layout

```
editfusion-ai/
├── apps/
│   ├── web/          # Next.js 15 frontend (App Router, Clerk, Tailwind, shadcn-style UI)
│   ├── api/           # NestJS REST API — auth, uploads, job enqueueing, billing, admin
│   ├── worker/         # Standalone BullMQ worker — actual file processing (pdf-lib, sharp)
│   └── mobile/         # Capacitor Android wrapper — see apps/mobile/README.md to build an APK
├── packages/
│   └── shared/         # Types shared between api and worker (job payload contracts)
├── infra/
│   ├── docker/
│   └── nginx/          # Reverse proxy config (rate limiting, upload size, routing)
├── .github/workflows/  # CI: lint/build/test + Docker image builds
├── docker-compose.yml   # Full local stack: postgres, redis, minio (S3-compatible), clamav, api, worker, web, nginx
└── .env.example
```

### Why the worker is a separate app, not a NestJS module

File processing (PDF merges, image compression, OCR, AI upscaling) is CPU/GPU-bound
and can take seconds to minutes. Running it inside the API process would block the
event loop and make the API's latency depend on unrelated users' job sizes. Instead:

- `apps/api` only ever does fast, cheap work: validate → upload to storage → write a
  `Job` row → push a small JSON payload onto a BullMQ queue → return immediately.
- `apps/worker` consumes queues independently, can be scaled horizontally
  (`docker-compose.yml` runs 2 replicas out of the box), and can be deployed on
  different hardware (e.g. GPU nodes for AI upscaling) without touching the API.
- Both sides only agree on the payload shape, defined once in `packages/shared`.

## What's fully implemented (run it today)

- **Auth**: Clerk-based `ClerkAuthGuard` verifying session JWTs, auto-provisioning
  local `User` rows, `@Public()` escape hatch for webhooks.
- **Uploads**: `POST /files/upload` — MIME allow-listing, size limits, a malware-scan
  hook (ClamAV daemon already in `docker-compose.yml`, wire-up point marked in
  `files.service.ts`), auto-expiry (`File.expiresAt`) for GDPR-friendly cleanup.
- **Merge PDF**: full slice — `POST /tools/pdf/merge` enqueues a job, the worker
  merges with `pdf-lib` reporting real progress, `GET /tools/pdf/merge/:jobId` is
  polled by the frontend, output is uploaded back to storage with a signed download URL.
- **Compress Image**: same pattern using `sharp`.
- **Billing**: Stripe Checkout session creation, billing portal, and a webhook
  handler that updates `Subscription` on `checkout.session.completed` /
  `customer.subscription.updated`.
- **Admin**: `AdminGuard` + overview/users/error-logs/contact-messages endpoints.
- **Frontend**: full landing page (hero, features, how-it-works, testimonials,
  pricing, FAQ, footer) with dark/light mode, glassmorphism, gradient accents, and
  Framer Motion micro-animations; authenticated dashboard shell; a fully wired
  Merge PDF tool page (drag-and-drop → upload → progress bar → download).
- **Infra**: Docker Compose for the full stack including MinIO (S3-compatible, so
  you never need real R2 credentials for local dev) and ClamAV; Nginx reverse proxy
  with rate limiting; GitHub Actions CI.

## Getting started

```bash
cp .env.example .env          # fill in Clerk + Stripe keys; MinIO defaults work locally
pnpm install
docker compose up --build     # postgres, redis, minio, clamav, api, worker, web, nginx
pnpm prisma:migrate           # apply the schema
```

- Frontend: http://localhost:3000
- API: http://localhost:4000/api/v1
- MinIO console: http://localhost:9001 (user/pass: `editfusion` / `editfusion123`)

## Roadmap — extending to full feature parity

Each item follows the **exact same pattern** as Merge PDF / Compress Image:
DTO + controller + jobs-service method (API) → processor function (worker) →
tool page (frontend). Budget roughly 0.5–1 day per tool once the pattern is familiar.

**Phase 1 — remaining core PDF tools** (`apps/worker/src/processors/`, all `pdf-lib`):
Split PDF, Compress PDF, Rotate PDF, Delete/Extract Pages, Organize Pages,
Watermark PDF, Add Page Numbers, Protect/Unlock PDF (use `pdf-lib` encryption or
`qpdf` via shell-out for stronger encryption).

**Phase 2 — conversions** (bring in `libreoffice` headless in the worker container
for Office↔PDF; `pdf-lib` + `pdf-to-png`/`pdf-img-convert` for PDF↔image):
Word↔PDF, Excel to PDF, PowerPoint to PDF, JPG/PNG↔PDF, PDF to JPG/PNG.

**Phase 3 — remaining image tools** (all `sharp`, same pattern as Compress Image):
Resize, Crop, Rotate, Flip, format conversions (JPG/PNG/WebP), SVG conversion,
Watermark Images, Remove Metadata (`sharp().withMetadata(false)`), Batch Processing
(accept `fileIds[]`, fan out to N BullMQ jobs, aggregate status).

**Phase 4 — AI tools** (new `AiToolsModule` controllers; worker calls
OpenAI/Replicate APIs — keys already scaffolded in `.env.example`):
Chat with PDF (embed + vector search, e.g. pgvector extension on the existing
Postgres), AI Summary, AI Translation, OCR (Tesseract.js or a hosted OCR API),
Extract Tables, Background Remover / Upscaler / Enhancer (Replicate models),
Form Detection, Signature Detection.

**Phase 5 — eSign**: dedicated `signatures` table (not yet in schema — add a
`SignatureRequest` model with signer email, field positions, status), a
signing-flow UI, and audit trail for legal validity.

**Phase 6 — remaining dashboard/admin pages**: File History, Favorites (backend
already has the `Favorite` model — just needs controller + page), Storage usage
chart, Notifications inbox, API key management UI, Coupons admin UI, Settings
(`SystemSetting` model already supports this).

**Phase 7 — hardening for production**: CSRF tokens on state-changing routes,
`class-validator` on every remaining DTO, integration tests per tool, load testing
the queue under concurrent uploads, S3 lifecycle rules as a second line of defense
for file auto-deletion (belt-and-suspenders alongside the app-level cleanup job),
and a proper `apps/worker` cleanup processor (`QUEUE_NAMES.CLEANUP`, referenced but
not yet implemented) that sweeps expired `File` rows on a cron schedule.

## Security posture already in place

HTTPS terminated at Nginx/Cloudflare · JWT verification via Clerk · global
`ThrottlerGuard` + Nginx `limit_req` (defense in depth) · `class-validator` +
`whitelist: true` (mitigates mass assignment) · Helmet security headers · MIME
allow-listing + size limits + ClamAV hook on every upload · signed, time-limited
download URLs (never public buckets) · automatic file expiry · centralized
exception filter that never leaks stack traces.
