import { Injectable } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { PrismaService } from '../../config/prisma.service';
import { QUEUE_NAMES } from '../../queue/queue.module';
import type { MergePdfJobData } from '@editfusion/shared';

// Pattern reused by every PDF/Image/AI tool controller: create a Job row
// (source of truth for status/progress the frontend polls), then hand a
// slim payload to BullMQ. Keeps the API stateless and horizontally scalable.
@Injectable()
export class PdfJobsService {
  constructor(private prisma: PrismaService, @InjectQueue(QUEUE_NAMES.PDF) private pdfQueue: Queue) {}

  async enqueueMerge(userId: string, fileIds: string[]) {
    const files = await this.prisma.file.findMany({ where: { id: { in: fileIds }, userId } });
    if (files.length !== fileIds.length) throw new Error('One or more files not found for this user');

    const job = await this.prisma.job.create({
      data: {
        userId,
        toolType: 'MERGE_PDF',
        category: 'PDF',
        status: 'QUEUED',
        inputFiles: { connect: fileIds.map((id) => ({ id })) },
      },
    });

    const bullJob = await this.pdfQueue.add('merge-pdf', {
      jobId: job.id,
      userId,
      fileKeys: files.map((f) => f.storageKey),
    } satisfies MergePdfJobData);

    await this.prisma.job.update({ where: { id: job.id }, data: { bullJobId: bullJob.id } });
    return job;
  }

  async getStatus(userId: string, jobId: string) {
    return this.prisma.job.findFirstOrThrow({ where: { id: jobId, userId }, include: { outputFile: true } });
  }
}
