import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { PdfJobsService } from './pdf-jobs.service';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import type { User } from '@prisma/client';
import { IsArray, ArrayMinSize, IsString } from 'class-validator';

class MergePdfDto {
  @IsArray()
  @ArrayMinSize(2, { message: 'Select at least 2 PDF files to merge' })
  @IsString({ each: true })
  fileIds!: string[];
}

// REST surface for the Merge PDF tool. Same shape (enqueue + poll status) is
// reused for every other PDF tool — split, compress, watermark, etc. — by
// adding a sibling controller + service pair and a matching worker processor.
@Controller('tools/pdf/merge')
export class MergePdfController {
  constructor(private pdfJobs: PdfJobsService) {}

  @Post()
  merge(@Body() dto: MergePdfDto, @CurrentUser() user: User) {
    return this.pdfJobs.enqueueMerge(user.id, dto.fileIds);
  }

  // Frontend polls this every ~1.5s to drive the real-time progress bar.
  @Get(':jobId')
  status(@Param('jobId') jobId: string, @CurrentUser() user: User) {
    return this.pdfJobs.getStatus(user.id, jobId);
  }
}
