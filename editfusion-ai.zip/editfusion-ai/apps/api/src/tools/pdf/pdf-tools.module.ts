import { Module } from '@nestjs/common';
import { MergePdfController } from './merge-pdf.controller';
import { PdfJobsService } from './pdf-jobs.service';

@Module({
  controllers: [MergePdfController],
  providers: [PdfJobsService],
})
export class PdfToolsModule {}
