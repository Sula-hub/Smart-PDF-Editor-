import { Body, Controller, Post } from '@nestjs/common';
import { IsInt, IsString, Max, Min } from 'class-validator';
import { ImageJobsService } from './image-jobs.service';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import type { User } from '@prisma/client';

class CompressImageDto {
  @IsString() fileId!: string;
  @IsInt() @Min(1) @Max(100) quality!: number;
}

@Controller('tools/image/compress')
export class CompressImageController {
  constructor(private imageJobs: ImageJobsService) {}

  @Post()
  compress(@Body() dto: CompressImageDto, @CurrentUser() user: User) {
    return this.imageJobs.enqueueCompress(user.id, dto.fileId, dto.quality);
  }
}
