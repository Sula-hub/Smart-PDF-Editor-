import { Module } from '@nestjs/common';
import { CompressImageController } from './compress-image.controller';
import { ImageJobsService } from './image-jobs.service';

// Mirrors PdfToolsModule's pattern. Additional image tools (resize, crop,
// bg-remove, upscale, ...) are added the same way: DTO + controller +
// service method that enqueues onto QUEUE_NAMES.IMAGE with a distinct
// `name` so the worker can route to the right handler.
@Module({
  controllers: [CompressImageController],
  providers: [ImageJobsService],
})
export class ImageToolsModule {}
