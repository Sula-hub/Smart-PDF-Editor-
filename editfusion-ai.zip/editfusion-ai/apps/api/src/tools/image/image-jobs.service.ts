import { Injectable } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { PrismaService } from '../../config/prisma.service';
import { QUEUE_NAMES } from '../../queue/queue.module';
import type { CompressImageJobData } from '@editfusion/shared';

@Injectable()
export class ImageJobsService {
  constructor(private prisma: PrismaService, @InjectQueue(QUEUE_NAMES.IMAGE) private imageQueue: Queue) {}

  async enqueueCompress(userId: string, fileId: string, quality: number) {
    const file = await this.prisma.file.findFirstOrThrow({ where: { id: fileId, userId } });

    const job = await this.prisma.job.create({
      data: {
        userId,
        toolType: 'COMPRESS_JPG',
        category: 'IMAGE',
        status: 'QUEUED',
        options: { quality },
        inputFiles: { connect: [{ id: fileId }] },
      },
    });

    const bullJob = await this.imageQueue.add('compress-image', {
      jobId: job.id,
      userId,
      fileKey: file.storageKey,
      quality,
    } satisfies CompressImageJobData);

    await this.prisma.job.update({ where: { id: job.id }, data: { bullJobId: bullJob.id } });
    return job;
  }
}
