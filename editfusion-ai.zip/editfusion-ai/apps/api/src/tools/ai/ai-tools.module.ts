import { Module } from '@nestjs/common';

// AI tools (Chat with PDF, Summary, Translation, Table extraction, ...)
// follow the identical enqueue-and-poll pattern as PDF/Image tools, routed
// onto QUEUE_NAMES.AI. Stubbed here — see README roadmap for build order.
@Module({})
export class AiToolsModule {}
