import { Controller, Get, Param, Post, UploadedFile, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { FilesService } from './files.service';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import type { User } from '@prisma/client';

@Controller('files')
export class FilesController {
  constructor(private filesService: FilesService) {}

  // Drag-and-drop upload target used by every tool page on the frontend.
  @Post('upload')
  @UseInterceptors(FileInterceptor('file', { limits: { fileSize: 100 * 1024 * 1024 } }))
  upload(@UploadedFile() file: Express.Multer.File, @CurrentUser() user: User) {
    return this.filesService.handleUpload(user.id, file);
  }

  @Get('recent')
  recent(@CurrentUser() user: User) {
    return this.filesService.listRecent(user.id);
  }

  @Get(':id/download-url')
  downloadUrl(@Param('id') id: string, @CurrentUser() user: User) {
    return this.filesService.getDownloadUrl(user.id, id);
  }
}
