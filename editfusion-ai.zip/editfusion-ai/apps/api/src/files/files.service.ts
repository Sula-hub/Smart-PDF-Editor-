import { BadRequestException, Injectable } from '@nestjs/common';
import { PrismaService } from '../config/prisma.service';
import { StorageService } from '../storage/storage.service';
import { ALLOWED_MIME_TYPES, MAX_FILE_SIZE_BYTES, isAllowedMime } from '../common/file-validation';

@Injectable()
export class FilesService {
  constructor(private prisma: PrismaService, private storage: StorageService) {}

  async handleUpload(userId: string, file: Express.Multer.File) {
    if (!isAllowedMime(file.mimetype)) {
      throw new BadRequestException(`Unsupported file type: ${file.mimetype}`);
    }
    if (file.size > MAX_FILE_SIZE_BYTES) {
      throw new BadRequestException('File exceeds maximum allowed size');
    }

    // Malware scan hook: in production this streams the buffer to a ClamAV
    // daemon (clamdjs) before it ever reaches storage or the queue.
    await this.scanForMalware(file.buffer);

    const key = this.storage.buildKey(userId, file.originalname);
    await this.storage.upload(key, file.buffer, file.mimetype);

    return this.prisma.file.create({
      data: {
        userId,
        originalName: file.originalname,
        mimeType: file.mimetype,
        sizeBytes: file.size,
        storageKey: key,
        status: 'UPLOADED',
        // Files not attached to a completed job auto-expire — enforced by
        // the cleanup queue processor (queue/cleanup.processor.ts).
        expiresAt: new Date(Date.now() + Number(process.env.FILE_TTL_MINUTES ?? 60) * 60_000),
      },
    });
  }

  private async scanForMalware(_buffer: Buffer): Promise<void> {
    // Placeholder for ClamAV integration — throws BadRequestException on detection.
    return;
  }

  async listRecent(userId: string, take = 20) {
    return this.prisma.file.findMany({ where: { userId }, orderBy: { createdAt: 'desc' }, take });
  }

  async getDownloadUrl(userId: string, fileId: string) {
    const file = await this.prisma.file.findFirstOrThrow({ where: { id: fileId, userId } });
    return this.storage.getSignedDownloadUrl(file.storageKey);
  }
}
