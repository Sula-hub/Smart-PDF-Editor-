import { createParamDecorator, ExecutionContext } from '@nestjs/common';

// Pulls the authenticated User row (attached by ClerkAuthGuard) into a handler arg:
//   findMine(@CurrentUser() user: User) { ... }
export const CurrentUser = createParamDecorator((_: unknown, ctx: ExecutionContext) => {
  return ctx.switchToHttp().getRequest().user;
});
