import { SetMetadata } from '@nestjs/common';

// Marks a route as exempt from the global ClerkAuthGuard (e.g. Stripe webhooks).
export const IS_PUBLIC_KEY = 'isPublic';
export const Public = () => SetMetadata(IS_PUBLIC_KEY, true);
