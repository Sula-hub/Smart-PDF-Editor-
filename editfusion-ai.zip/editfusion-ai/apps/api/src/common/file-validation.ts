// Shared allow-list based file validation — never trust the client-supplied
// mimetype alone; this pairs with magic-byte sniffing in production
// (e.g. `file-type` package) before anything is queued for processing.
export const ALLOWED_MIME_TYPES: Record<string, string[]> = {
  pdf: ['application/pdf'],
  image: ['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml'],
  office: [
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  ],
};

export const MAX_FILE_SIZE_BYTES = 100 * 1024 * 1024; // 100MB, tune per plan tier

export function isAllowedMime(mime: string): boolean {
  return Object.values(ALLOWED_MIME_TYPES).flat().includes(mime);
}
