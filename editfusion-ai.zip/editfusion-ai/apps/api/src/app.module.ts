import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { APP_GUARD } from '@nestjs/core';
import { BullModule } from '@nestjs/bullmq';

import { PrismaModule } from './config/prisma.module';
import { AuthModule } from './auth/auth.module';
import { StorageModule } from './storage/storage.module';
import { FilesModule } from './files/files.module';
import { QueueModule } from './queue/queue.module';
import { PdfToolsModule } from './tools/pdf/pdf-tools.module';
import { ImageToolsModule } from './tools/image/image-tools.module';
import { AiToolsModule } from './tools/ai/ai-tools.module';
import { SubscriptionsModule } from './subscriptions/subscriptions.module';
import { AdminModule } from './admin/admin.module';
import { UsersModule } from './users/users.module';
import { NotificationsModule } from './notifications/notifications.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    // Global rate limiting — mitigates brute force / abuse (Security: Rate Limiting)
    ThrottlerModule.forRoot([
      { ttl: Number(process.env.RATE_LIMIT_TTL ?? 60) * 1000, limit: Number(process.env.RATE_LIMIT_MAX ?? 100) },
    ]),
    BullModule.forRoot({ connection: { url: process.env.REDIS_URL } }),
    PrismaModule,
    AuthModule,
    StorageModule,
    QueueModule,
    FilesModule,
    PdfToolsModule,
    ImageToolsModule,
    AiToolsModule,
    SubscriptionsModule,
    AdminModule,
    UsersModule,
    NotificationsModule,
  ],
  providers: [{ provide: APP_GUARD, useClass: ThrottlerGuard }],
})
export class AppModule {}
