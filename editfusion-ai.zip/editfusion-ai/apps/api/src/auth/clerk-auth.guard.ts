import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { verifyToken } from '@clerk/backend';
import { PrismaService } from '../config/prisma.service';
import { IS_PUBLIC_KEY } from '../common/decorators/public.decorator';

// Verifies the Clerk session JWT sent in the Authorization header, then
// resolves (or lazily creates) the matching local User row and attaches
// it to the request so downstream controllers get a typed, trusted user.
@Injectable()
export class ClerkAuthGuard implements CanActivate {
  constructor(private reflector: Reflector, private prisma: PrismaService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPublic) return true;

    const req = context.switchToHttp().getRequest();
    const authHeader: string | undefined = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) throw new UnauthorizedException('Missing bearer token');

    const token = authHeader.slice('Bearer '.length);
    try {
      const payload = await verifyToken(token, { secretKey: process.env.CLERK_SECRET_KEY! });

      const user = await this.prisma.user.upsert({
        where: { clerkId: payload.sub },
        update: { lastLoginAt: new Date() },
        create: {
          clerkId: payload.sub,
          email: (payload as any).email ?? `${payload.sub}@placeholder.editfusion.ai`,
        },
      });

      req.user = user; // available to controllers via @CurrentUser()
      return true;
    } catch {
      throw new UnauthorizedException('Invalid or expired session token');
    }
  }
}
