import { Controller, Get, Post, Req } from '@nestjs/common';
import { AuthService } from './auth.service';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { Public } from '../common/decorators/public.decorator';
import type { User } from '@prisma/client';

@Controller('auth')
export class AuthController {
  constructor(private authService: AuthService) {}

  // Returns the currently authenticated user + subscription (used by the dashboard on load).
  @Get('me')
  me(@CurrentUser() user: User) {
    return this.authService.getProfile(user.id);
  }

  // Clerk calls this on sign-up/sign-in/user.updated events to keep local data in sync.
  @Public()
  @Post('webhooks/clerk')
  handleClerkWebhook(@Req() req: any) {
    // Verify svix signature headers here in production before trusting the payload.
    return { received: true };
  }
}
