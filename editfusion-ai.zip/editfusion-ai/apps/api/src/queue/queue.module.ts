import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';

// Central place that registers every named queue. Tool controllers inject
// the relevant queue and enqueue a job; actual processing happens in the
// separate `apps/worker` process so heavy CPU/GPU work never blocks the API.
export const QUEUE_NAMES = {
  PDF: 'pdf-processing',
  IMAGE: 'image-processing',
  AI: 'ai-processing',
  CLEANUP: 'file-cleanup',
} as const;

@Module({
  imports: [
    BullModule.registerQueue(
      { name: QUEUE_NAMES.PDF },
      { name: QUEUE_NAMES.IMAGE },
      { name: QUEUE_NAMES.AI },
      { name: QUEUE_NAMES.CLEANUP },
    ),
  ],
  exports: [BullModule],
})
export class QueueModule {}
