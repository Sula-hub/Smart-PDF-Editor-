import { Injectable } from '@nestjs/common';
import Stripe from 'stripe';
import { PrismaService } from '../config/prisma.service';

const PRICE_TO_TIER: Record<string, 'PRO' | 'BUSINESS'> = {
  [process.env.STRIPE_PRICE_PRO ?? '']: 'PRO',
  [process.env.STRIPE_PRICE_BUSINESS ?? '']: 'BUSINESS',
};

@Injectable()
export class SubscriptionsService {
  private stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-06-20' });

  constructor(private prisma: PrismaService) {}

  async createCheckoutSession(userId: string, userEmail: string, priceId: string) {
    const session = await this.stripe.checkout.sessions.create({
      mode: 'subscription',
      customer_email: userEmail,
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: `${process.env.APP_URL}/dashboard/billing?success=true`,
      cancel_url: `${process.env.APP_URL}/pricing`,
      metadata: { userId },
    });
    return { url: session.url };
  }

  async createBillingPortalSession(customerId: string) {
    const session = await this.stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: `${process.env.APP_URL}/dashboard/billing`,
    });
    return { url: session.url };
  }

  // Called from the (raw-body) webhook controller after signature verification.
  async handleWebhookEvent(event: Stripe.Event) {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        const userId = session.metadata?.userId;
        if (!userId) break;
        await this.prisma.subscription.upsert({
          where: { userId },
          update: { stripeCustomerId: session.customer as string, status: 'ACTIVE' },
          create: { userId, stripeCustomerId: session.customer as string, status: 'ACTIVE' },
        });
        break;
      }
      case 'customer.subscription.updated':
      case 'customer.subscription.deleted': {
        const sub = event.data.object as Stripe.Subscription;
        const priceId = sub.items.data[0]?.price.id;
        await this.prisma.subscription.updateMany({
          where: { stripeSubscriptionId: sub.id },
          data: {
            status: sub.status === 'active' ? 'ACTIVE' : sub.status === 'past_due' ? 'PAST_DUE' : 'CANCELED',
            tier: PRICE_TO_TIER[priceId ?? ''] ?? 'FREE',
            currentPeriodEnd: new Date(sub.current_period_end * 1000),
            cancelAtPeriodEnd: sub.cancel_at_period_end,
          },
        });
        break;
      }
    }
  }
}
