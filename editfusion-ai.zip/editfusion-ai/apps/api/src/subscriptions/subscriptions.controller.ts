import { Body, Controller, Headers, Post, RawBodyRequest, Req } from '@nestjs/common';
import Stripe from 'stripe';
import { SubscriptionsService } from './subscriptions.service';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { Public } from '../common/decorators/public.decorator';
import type { User } from '@prisma/client';

@Controller('subscriptions')
export class SubscriptionsController {
  private stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-06-20' });

  constructor(private subscriptions: SubscriptionsService) {}

  @Post('checkout')
  checkout(@Body('priceId') priceId: string, @CurrentUser() user: User) {
    return this.subscriptions.createCheckoutSession(user.id, user.email, priceId);
  }

  // Stripe webhook — public route, trust established via signature verification only.
  @Public()
  @Post('webhook')
  async webhook(@Req() req: RawBodyRequest<Request>, @Headers('stripe-signature') sig: string) {
    const event = this.stripe.webhooks.constructEvent(req.rawBody!, sig, process.env.STRIPE_WEBHOOK_SECRET!);
    await this.subscriptions.handleWebhookEvent(event);
    return { received: true };
  }
}
