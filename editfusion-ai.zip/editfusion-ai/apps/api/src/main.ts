import { NestFactory } from '@nestjs/core';
import helmet from 'helmet';
import { ValidationPipe } from '@nestjs/common';
import { AppModule } from './app.module';
import { AllExceptionsFilter } from './common/filters/all-exceptions.filter';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, { cors: { origin: process.env.APP_URL, credentials: true } });

  // --- Security hardening ---
  app.use(helmet()); // sets sane security headers (XSS, sniffing, etc.)
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,        // strips unknown props -> mitigates mass-assignment
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );
  app.useGlobalFilters(new AllExceptionsFilter()); // consistent error shape + logging to ErrorLog

  app.setGlobalPrefix('api/v1');

  const port = process.env.API_PORT || 4000;
  await app.listen(port);
  console.log(`EditFusion API listening on :${port}`);
}
bootstrap();
