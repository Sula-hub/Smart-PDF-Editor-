import { Injectable } from '@nestjs/common';
import { PrismaService } from '../config/prisma.service';

@Injectable()
export class AdminService {
  constructor(private prisma: PrismaService) {}

  // Powers the Analytics + Revenue dashboards.
  async getOverview() {
    const [totalUsers, activeSubscriptions, jobsToday, failedJobsToday] = await Promise.all([
      this.prisma.user.count(),
      this.prisma.subscription.count({ where: { status: 'ACTIVE', tier: { not: 'FREE' } } }),
      this.prisma.job.count({ where: { createdAt: { gte: startOfToday() } } }),
      this.prisma.job.count({ where: { status: 'FAILED', createdAt: { gte: startOfToday() } } }),
    ]);
    return { totalUsers, activeSubscriptions, jobsToday, failedJobsToday };
  }

  async listUsers(skip = 0, take = 50) {
    return this.prisma.user.findMany({ skip, take, include: { subscription: true }, orderBy: { createdAt: 'desc' } });
  }

  async listErrorLogs(take = 100) {
    return this.prisma.errorLog.findMany({ take, orderBy: { createdAt: 'desc' } });
  }

  async listContactMessages(take = 100) {
    return this.prisma.contactMessage.findMany({ take, orderBy: { createdAt: 'desc' } });
  }
}

function startOfToday() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}
