import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';

// Runs after ClerkAuthGuard (req.user already populated); restricts
// admin-panel routes to Role.ADMIN / Role.SUPPORT.
@Injectable()
export class AdminGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const { user } = context.switchToHttp().getRequest();
    if (!user || !['ADMIN', 'SUPPORT'].includes(user.role)) {
      throw new ForbiddenException('Admin access required');
    }
    return true;
  }
}
