import { Controller, Get, UseGuards } from '@nestjs/common';
import { AdminService } from './admin.service';
import { AdminGuard } from './admin.guard';

@Controller('admin')
@UseGuards(AdminGuard)
export class AdminController {
  constructor(private admin: AdminService) {}

  @Get('overview')
  overview() {
    return this.admin.getOverview();
  }

  @Get('users')
  users() {
    return this.admin.listUsers();
  }

  @Get('error-logs')
  errorLogs() {
    return this.admin.listErrorLogs();
  }

  @Get('contact-messages')
  contactMessages() {
    return this.admin.listContactMessages();
  }
}
