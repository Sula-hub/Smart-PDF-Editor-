import type { CapacitorConfig } from '@capacitor/cli';

// EditFusion AI is a full Next.js app (server components, auth, file
// uploads) — not a static site — so this wraps the *deployed* web app in a
// native WebView shell rather than bundling static assets into the APK.
// Point `server.url` at your production/staging deployment. Swap to a
// `webDir` + static export only if you later ship an offline-capable subset.
const config: CapacitorConfig = {
  appId: 'ai.editfusion.app',
  appName: 'EditFusion AI',
  webDir: 'www', // placeholder dir required by Capacitor even in server-url mode; see www/.gitkeep
  server: {
    // Replace with your real domain before building; https is required.
    url: process.env.EDITFUSION_WEB_URL || 'https://app.editfusion.ai',
    cleartext: false,
    androidScheme: 'https',
  },
  android: {
    allowMixedContent: false,
    captureInput: true,
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 800,
      backgroundColor: '#0B0B12',
      androidSplashResourceName: 'splash',
      showSpinner: false,
    },
  },
};

export default config;
