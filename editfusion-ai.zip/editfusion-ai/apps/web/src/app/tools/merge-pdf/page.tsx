'use client';
import { useCallback, useRef, useState } from 'react';
import { useAuth } from '@clerk/nextjs';
import { motion, AnimatePresence } from 'framer-motion';
import { UploadCloud, FileText, X, Download, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { apiFetch } from '@/lib/api';

type UploadedFile = { id: string; originalName: string };
type JobState = 'idle' | 'uploading' | 'queued' | 'processing' | 'done' | 'error';

// Full working example of the "upload -> enqueue -> poll -> download"
// pattern every tool page follows. Copy this file, swap the endpoint and
// the minimum-file-count rule, and you have a new tool page in minutes.
export default function MergePdfPage() {
  const { getToken } = useAuth();
  const inputRef = useRef<HTMLInputElement>(null);

  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [state, setState] = useState<JobState>('idle');
  const [progress, setProgress] = useState(0);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFiles = useCallback(async (fileList: FileList) => {
    setState('uploading');
    setError(null);
    try {
      const token = await getToken();
      if (!token) throw new Error('Not authenticated');

      const uploaded: UploadedFile[] = [];
      for (const file of Array.from(fileList)) {
        const form = new FormData();
        form.append('file', file);
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/files/upload`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
          body: form,
        });
        if (!res.ok) throw new Error('Upload failed — check file type and size');
        uploaded.push(await res.json());
      }
      setFiles((prev) => [...prev, ...uploaded]);
      setState('idle');
    } catch (e: any) {
      setError(e.message);
      setState('error');
    }
  }, [getToken]);

  const startMerge = useCallback(async () => {
    if (files.length < 2) return;
    setState('queued');
    setError(null);
    try {
      const token = await getToken();
      if (!token) throw new Error('Not authenticated');

      const job = await apiFetch('/tools/pdf/merge', token, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fileIds: files.map((f) => f.id) }),
      });

      // Real-time progress bar via polling (swap for a WebSocket/SSE
      // subscription later without changing the rest of the page).
      const poll = setInterval(async () => {
        const t = await getToken();
        if (!t) return;
        const status = await apiFetch(`/tools/pdf/merge/${job.id}`, t);
        setProgress(status.progress);
        setState(status.status === 'ACTIVE' ? 'processing' : state);

        if (status.status === 'COMPLETED') {
          clearInterval(poll);
          const url = await apiFetch(`/files/${status.outputFileId}/download-url`, t);
          setDownloadUrl(url);
          setState('done');
        }
        if (status.status === 'FAILED') {
          clearInterval(poll);
          setError(status.errorMessage ?? 'Processing failed');
          setState('error');
        }
      }, 1500);
    } catch (e: any) {
      setError(e.message);
      setState('error');
    }
  }, [files, getToken, state]);

  return (
    <div className="mx-auto max-w-2xl px-6 py-16">
      <h1 className="text-3xl font-semibold tracking-tight">Merge PDF</h1>
      <p className="mt-2 text-zinc-500 dark:text-zinc-400">Combine multiple PDFs into one, in the order you choose.</p>

      <Card
        className="mt-8 flex flex-col items-center justify-center border-2 border-dashed border-zinc-300 py-14 text-center dark:border-zinc-700"
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => { e.preventDefault(); if (e.dataTransfer.files.length) handleFiles(e.dataTransfer.files); }}
      >
        <UploadCloud className="h-8 w-8 text-brand-500" />
        <p className="mt-3 text-sm font-medium">Drag and drop PDFs here</p>
        <p className="text-xs text-zinc-400">or</p>
        <Button size="sm" variant="secondary" className="mt-3" onClick={() => inputRef.current?.click()}>
          Browse files
        </Button>
        <input
          ref={inputRef}
          type="file"
          accept="application/pdf"
          multiple
          className="hidden"
          onChange={(e) => e.target.files && handleFiles(e.target.files)}
        />
      </Card>

      <AnimatePresence>
        {files.length > 0 && (
          <motion.ul initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-5 space-y-2">
            {files.map((f) => (
              <li key={f.id} className="flex items-center justify-between rounded-xl glass px-4 py-2.5 text-sm">
                <span className="flex items-center gap-2"><FileText className="h-4 w-4 text-brand-500" /> {f.originalName}</span>
                <button onClick={() => setFiles((prev) => prev.filter((x) => x.id !== f.id))} aria-label="Remove file">
                  <X className="h-4 w-4 text-zinc-400 hover:text-zinc-600" />
                </button>
              </li>
            ))}
          </motion.ul>
        )}
      </AnimatePresence>

      {error && <p className="mt-4 text-sm text-red-500">{error}</p>}

      {state === 'done' && downloadUrl ? (
        <a href={downloadUrl} target="_blank" rel="noreferrer">
          <Button className="mt-6 w-full" size="lg">
            <Download className="mr-2 h-4 w-4" /> Download merged PDF
          </Button>
        </a>
      ) : (
        <Button
          className="mt-6 w-full"
          size="lg"
          disabled={files.length < 2 || state === 'queued' || state === 'processing' || state === 'uploading'}
          onClick={startMerge}
        >
          {state === 'queued' || state === 'processing' ? (
            <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Merging… {progress}%</>
          ) : (
            `Merge ${files.length || ''} PDFs`
          )}
        </Button>
      )}
    </div>
  );
}
