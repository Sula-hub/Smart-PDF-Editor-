import { Hero } from '@/components/marketing/hero';
import { Features } from '@/components/marketing/features';
import { HowItWorks } from '@/components/marketing/how-it-works';
import { Testimonials } from '@/components/marketing/testimonials';
import { Pricing } from '@/components/marketing/pricing';
import { Faq } from '@/components/marketing/faq';
import { Footer } from '@/components/marketing/footer';
import { Navbar } from '@/components/marketing/navbar';

// The full premium landing page — assembled from independent, reusable
// sections so the blog, pricing, and marketing pages can reuse the same nav/footer.
export default function LandingPage() {
  return (
    <>
      <Navbar />
      <Hero />
      <Features />
      <HowItWorks />
      <Testimonials />
      <Pricing />
      <Faq />
      <Footer />
    </>
  );
}
