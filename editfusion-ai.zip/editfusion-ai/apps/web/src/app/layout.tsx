import type { Metadata } from 'next';
import { ClerkProvider } from '@clerk/nextjs';
import './globals.css';

export const metadata: Metadata = {
  title: 'EditFusion AI — Edit, Convert & Enhance Files with AI',
  description:
    'Merge, split, compress, edit and convert PDFs and images in seconds — powered by AI. A faster, more beautiful alternative to iLovePDF and Smallpdf.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider>
      <html lang="en" suppressHydrationWarning>
        {/* Respects system dark/light mode by default; a theme toggle in the
            nav flips the `dark` class for manual override. */}
        <body className="min-h-screen bg-gradient-to-b from-white to-zinc-50 dark:from-zinc-950 dark:to-black text-zinc-900 dark:text-zinc-50 antialiased">
          {children}
        </body>
      </html>
    </ClerkProvider>
  );
}
