import { Card } from '@/components/ui/card';
import Link from 'next/link';

const TOOL_SHORTCUTS = [
  { href: '/tools/merge-pdf', label: 'Merge PDF' },
  { href: '/tools/compress-image', label: 'Compress Image' },
  { href: '/tools/split-pdf', label: 'Split PDF' },
  { href: '/tools/pdf-to-word', label: 'PDF to Word' },
];

// Landing view after login — recent activity + quick tool access.
// Real data (recent files, usage) is fetched client-side from
// GET /files/recent and GET /auth/me via lib/api.ts.
export default function DashboardOverview() {
  return (
    <div className="max-w-5xl">
      <h1 className="text-2xl font-semibold">Welcome back</h1>
      <p className="mt-1 text-sm text-zinc-500 dark:text-zinc-400">Pick up where you left off, or start a new tool.</p>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {TOOL_SHORTCUTS.map((t) => (
          <Link key={t.href} href={t.href}>
            <Card className="text-center font-medium hover:-translate-y-0.5">{t.label}</Card>
          </Link>
        ))}
      </div>

      <h2 className="mt-12 text-lg font-semibold">Recent files</h2>
      <Card className="mt-4">
        <p className="text-sm text-zinc-500 dark:text-zinc-400">
          Your recently processed files will appear here.
        </p>
      </Card>
    </div>
  );
}
