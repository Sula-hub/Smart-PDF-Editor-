import Link from 'next/link';
import { UserButton } from '@clerk/nextjs';
import { LayoutGrid, FileClock, Star, HardDrive, CreditCard, Settings, Bell } from 'lucide-react';

const NAV = [
  { href: '/dashboard', label: 'Overview', icon: LayoutGrid },
  { href: '/dashboard/history', label: 'File History', icon: FileClock },
  { href: '/dashboard/favorites', label: 'Favorites', icon: Star },
  { href: '/dashboard/storage', label: 'Storage', icon: HardDrive },
  { href: '/dashboard/billing', label: 'Billing', icon: CreditCard },
  { href: '/dashboard/notifications', label: 'Notifications', icon: Bell },
  { href: '/dashboard/settings', label: 'Settings', icon: Settings },
];

// Shared shell for every authenticated dashboard route: Recent Files,
// Favorites, History, Storage, Subscription, Notifications, Profile, Billing, API Access.
export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen">
      <aside className="hidden w-64 shrink-0 flex-col border-r border-zinc-200 p-5 dark:border-zinc-800 sm:flex">
        <div className="mb-8 flex items-center justify-between">
          <span className="font-semibold">EditFusion AI</span>
          <UserButton afterSignOutUrl="/" />
        </div>
        <nav className="space-y-1">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-zinc-600 transition-colors hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800"
            >
              <item.icon className="h-4 w-4" /> {item.label}
            </Link>
          ))}
        </nav>
      </aside>
      <main className="flex-1 p-6 sm:p-10">{children}</main>
    </div>
  );
}
