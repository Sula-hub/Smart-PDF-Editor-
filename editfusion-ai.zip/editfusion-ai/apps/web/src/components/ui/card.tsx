import { HTMLAttributes } from 'react';
import { cn } from '@/lib/utils';

export function Card({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        'glass rounded-3xl p-6 shadow-sm shadow-black/5 transition-shadow hover:shadow-xl hover:shadow-black/5',
        className,
      )}
      {...props}
    />
  );
}
