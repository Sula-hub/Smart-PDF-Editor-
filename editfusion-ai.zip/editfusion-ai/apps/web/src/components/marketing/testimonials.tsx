import { Card } from '@/components/ui/card';

const QUOTES = [
  { name: 'Priya S.', role: 'Operations Lead', text: 'We replaced three different tools with EditFusion. The batch processing alone saves our team hours every week.' },
  { name: 'Marcus T.', role: 'Freelance Designer', text: 'The AI background remover is as good as paid Photoshop plugins, and it\u2019s built right into the PDF workflow.' },
  { name: 'Elena R.', role: 'Legal Assistant', text: 'eSign and Protect PDF cover everything I used to need a separate contract tool for.' },
];

export function Testimonials() {
  return (
    <section className="px-6 py-24">
      <div className="mx-auto max-w-6xl">
        <h2 className="text-center text-3xl font-semibold tracking-tight sm:text-4xl">Loved by teams everywhere</h2>
        <div className="mt-14 grid gap-5 sm:grid-cols-3">
          {QUOTES.map((q) => (
            <Card key={q.name}>
              <p className="text-sm text-zinc-600 dark:text-zinc-300">&ldquo;{q.text}&rdquo;</p>
              <p className="mt-4 text-sm font-semibold">{q.name}</p>
              <p className="text-xs text-zinc-400">{q.role}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
