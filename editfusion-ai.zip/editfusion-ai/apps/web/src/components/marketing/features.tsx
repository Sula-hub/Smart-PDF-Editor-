'use client';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import {
  FileText, Scissors, Shrink, Droplets, Lock, ScanText,
  Image as ImageIcon, Wand2, MessageSquareText, Languages,
} from 'lucide-react';

const FEATURES = [
  { icon: FileText, title: 'Merge & Split PDF', desc: 'Combine or split documents in seconds with drag-and-drop reordering.' },
  { icon: Shrink, title: 'Compress Files', desc: 'Shrink PDFs and images without visible quality loss.' },
  { icon: Scissors, title: 'Organize Pages', desc: 'Reorder, rotate, delete or extract pages visually.' },
  { icon: Droplets, title: 'Watermark & Sign', desc: 'Add watermarks, page numbers, or a legally-binding eSignature.' },
  { icon: Lock, title: 'Protect & Unlock', desc: 'Password-protect sensitive PDFs or remove restrictions you own.' },
  { icon: ScanText, title: 'OCR & Extract Tables', desc: 'Turn scanned documents into searchable, structured data.' },
  { icon: ImageIcon, title: 'Image Toolkit', desc: 'Resize, crop, convert and batch-process images at scale.' },
  { icon: Wand2, title: 'AI Background Remover', desc: 'Remove backgrounds and upscale images with one click.' },
  { icon: MessageSquareText, title: 'Chat with your PDF', desc: 'Ask questions and get instant, cited answers from any document.' },
  { icon: Languages, title: 'AI Translation & Summary', desc: 'Summarize and translate long documents into 40+ languages.' },
];

export function Features() {
  return (
    <section id="features" className="px-6 py-24">
      <div className="mx-auto max-w-6xl">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-semibold tracking-tight sm:text-4xl">One workspace, every file tool</h2>
          <p className="mt-3 text-zinc-500 dark:text-zinc-400">
            30+ PDF tools, a full image toolkit, and AI features that used to need five different apps.
          </p>
        </div>

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-40px' }}
              transition={{ duration: 0.5, delay: (i % 3) * 0.08 }}
            >
              <Card>
                <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-brand-gradient">
                  <f.icon className="h-5 w-5 text-white" />
                </div>
                <h3 className="mt-4 font-semibold">{f.title}</h3>
                <p className="mt-1.5 text-sm text-zinc-500 dark:text-zinc-400">{f.desc}</p>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
