'use client';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, Sparkles } from 'lucide-react';

export function Hero() {
  return (
    <section className="relative overflow-hidden px-6 pt-32 pb-24 text-center">
      {/* Soft gradient orb backdrop — signature Apple/Linear-style hero glow */}
      <div className="pointer-events-none absolute inset-0 -z-10 flex justify-center">
        <div className="h-[36rem] w-[36rem] rounded-full bg-brand-gradient opacity-20 blur-[120px]" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="mx-auto inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-sm font-medium"
      >
        <Sparkles className="h-4 w-4 text-brand-500" />
        Now with AI-powered editing
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
        className="mx-auto mt-6 max-w-3xl text-5xl font-semibold tracking-tight sm:text-6xl"
      >
        Every file tool you need,
        <span className="bg-brand-gradient bg-clip-text text-transparent"> reimagined with AI</span>
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="mx-auto mt-5 max-w-xl text-lg text-zinc-500 dark:text-zinc-400"
      >
        Merge, compress, convert and edit PDFs and images in seconds. No installs, no watermarks,
        files deleted automatically after processing.
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
        className="mt-9 flex flex-wrap items-center justify-center gap-4"
      >
        <Button size="lg">
          Get started free <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
        <Button size="lg" variant="secondary">
          See all tools
        </Button>
      </motion.div>

      <p className="mt-6 text-xs text-zinc-400">No credit card required · Free plan forever</p>
    </section>
  );
}
