const STEPS = [
  { n: '01', title: 'Upload your file', desc: 'Drag and drop or pick from your device — files upload directly and securely.' },
  { n: '02', title: 'Choose a tool', desc: 'Pick from 40+ PDF, image and AI tools, or let AI suggest the right one.' },
  { n: '03', title: 'Download the result', desc: 'Get your processed file instantly. It\u2019s auto-deleted from our servers shortly after.' },
];

export function HowItWorks() {
  return (
    <section id="how-it-works" className="px-6 py-24">
      <div className="mx-auto max-w-5xl">
        <h2 className="text-center text-3xl font-semibold tracking-tight sm:text-4xl">How it works</h2>
        <div className="mt-14 grid gap-8 sm:grid-cols-3">
          {STEPS.map((s) => (
            <div key={s.n} className="text-center">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-gradient text-sm font-semibold text-white">
                {s.n}
              </div>
              <h3 className="mt-4 font-semibold">{s.title}</h3>
              <p className="mt-1.5 text-sm text-zinc-500 dark:text-zinc-400">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
