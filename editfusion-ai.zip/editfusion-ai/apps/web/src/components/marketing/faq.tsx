const FAQS = [
  { q: 'Are my files kept private?', a: 'Yes. Files are encrypted in transit and at rest, processed only for your request, and automatically deleted from our servers shortly after processing (see our privacy policy for exact retention windows).' },
  { q: 'Do I need to install anything?', a: 'No — EditFusion runs entirely in your browser and in our secure processing cloud. Nothing to download.' },
  { q: 'Can I use this for my team?', a: 'The Business plan includes team seats, shared usage limits, and an admin dashboard for managing members.' },
  { q: 'What happens if I exceed my plan limit?', a: 'We\u2019ll prompt you to upgrade before any file is blocked \u2014 we never fail silently.' },
];

export function Faq() {
  return (
    <section id="faq" className="px-6 py-24">
      <div className="mx-auto max-w-3xl">
        <h2 className="text-center text-3xl font-semibold tracking-tight sm:text-4xl">Frequently asked questions</h2>
        <div className="mt-10 divide-y divide-zinc-200 dark:divide-zinc-800">
          {FAQS.map((f) => (
            <details key={f.q} className="group py-5">
              <summary className="cursor-pointer list-none font-medium marker:content-none">
                {f.q}
              </summary>
              <p className="mt-2 text-sm text-zinc-500 dark:text-zinc-400">{f.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}
