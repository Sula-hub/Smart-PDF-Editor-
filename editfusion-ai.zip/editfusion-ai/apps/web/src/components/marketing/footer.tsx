export function Footer() {
  return (
    <footer className="border-t border-zinc-200 px-6 py-12 dark:border-zinc-800">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-6 sm:flex-row">
        <p className="text-sm font-semibold">EditFusion AI</p>
        <nav className="flex flex-wrap justify-center gap-6 text-sm text-zinc-500 dark:text-zinc-400">
          <a href="#features" className="hover:text-zinc-900 dark:hover:text-white">Features</a>
          <a href="#pricing" className="hover:text-zinc-900 dark:hover:text-white">Pricing</a>
          <a href="/blog" className="hover:text-zinc-900 dark:hover:text-white">Blog</a>
          <a href="/privacy" className="hover:text-zinc-900 dark:hover:text-white">Privacy</a>
          <a href="/contact" className="hover:text-zinc-900 dark:hover:text-white">Contact</a>
        </nav>
        <p className="text-xs text-zinc-400">© {new Date().getFullYear()} EditFusion AI. All rights reserved.</p>
      </div>
    </footer>
  );
}
