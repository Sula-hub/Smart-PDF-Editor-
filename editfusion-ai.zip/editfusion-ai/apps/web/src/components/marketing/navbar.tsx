'use client';
import Link from 'next/link';
import { SignedIn, SignedOut, SignInButton, UserButton } from '@clerk/nextjs';
import { Button } from '@/components/ui/button';

export function Navbar() {
  return (
    <header className="sticky top-4 z-50 mx-auto flex max-w-6xl items-center justify-between rounded-2xl glass px-5 py-3">
      <Link href="/" className="font-semibold tracking-tight">
        EditFusion <span className="bg-brand-gradient bg-clip-text text-transparent">AI</span>
      </Link>

      <nav className="hidden gap-6 text-sm text-zinc-600 dark:text-zinc-300 sm:flex">
        <a href="#features" className="hover:text-zinc-900 dark:hover:text-white">Features</a>
        <a href="#how-it-works" className="hover:text-zinc-900 dark:hover:text-white">How it works</a>
        <a href="#pricing" className="hover:text-zinc-900 dark:hover:text-white">Pricing</a>
        <a href="#faq" className="hover:text-zinc-900 dark:hover:text-white">FAQ</a>
      </nav>

      <div className="flex items-center gap-3">
        <SignedOut>
          <SignInButton mode="modal">
            <Button size="sm" variant="secondary">Log in</Button>
          </SignInButton>
          <SignInButton mode="modal">
            <Button size="sm">Get started</Button>
          </SignInButton>
        </SignedOut>
        <SignedIn>
          <Link href="/dashboard"><Button size="sm" variant="secondary">Dashboard</Button></Link>
          <UserButton afterSignOutUrl="/" />
        </SignedIn>
      </div>
    </header>
  );
}
