import { Check } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const PLANS = [
  { name: 'Free', price: '$0', tier: 'FREE', features: ['15 files / month', '10MB max file size', 'Core PDF & image tools', 'Standard processing speed'] },
  { name: 'Pro', price: '$12', tier: 'PRO', highlighted: true, features: ['1,000 files / month', '200MB max file size', 'All AI tools', 'Priority processing', 'No watermarks'] },
  { name: 'Business', price: '$39', tier: 'BUSINESS', features: ['10,000 files / month', '500MB max file size', 'API access', 'Team seats & admin controls', 'Priority support'] },
];

export function Pricing() {
  return (
    <section id="pricing" className="px-6 py-24">
      <div className="mx-auto max-w-5xl">
        <div className="text-center">
          <h2 className="text-3xl font-semibold tracking-tight sm:text-4xl">Simple, transparent pricing</h2>
          <p className="mt-3 text-zinc-500 dark:text-zinc-400">Start free. Upgrade when you need more.</p>
        </div>

        <div className="mt-14 grid gap-6 sm:grid-cols-3">
          {PLANS.map((p) => (
            <Card key={p.name} className={p.highlighted ? 'ring-2 ring-brand-500' : ''}>
              <h3 className="font-semibold">{p.name}</h3>
              <p className="mt-2 text-3xl font-semibold">
                {p.price}
                <span className="text-sm font-normal text-zinc-400"> /mo</span>
              </p>
              <ul className="mt-5 space-y-2.5">
                {p.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-sm text-zinc-600 dark:text-zinc-300">
                    <Check className="h-4 w-4 shrink-0 text-brand-500" /> {f}
                  </li>
                ))}
              </ul>
              <Button className="mt-6 w-full" variant={p.highlighted ? 'primary' : 'secondary'}>
                {p.tier === 'FREE' ? 'Start free' : 'Choose ' + p.name}
              </Button>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
