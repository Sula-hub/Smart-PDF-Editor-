/** @type {import('next').NextConfig} */
module.exports = {
  reactStrictMode: true,
  images: { remotePatterns: [{ protocol: 'https', hostname: '**' }] }, // Next/Image optimization for R2-hosted assets
  experimental: { serverActions: { bodySizeLimit: '100mb' } },
};
