import type { Config } from 'tailwindcss';

export default {
  darkMode: 'class',
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#f0f5ff', 100: '#dbe6ff', 300: '#a3bfff', 500: '#4f6df5',
          600: '#3b52d9', 700: '#2c3fae', 900: '#1a2566',
        },
      },
      borderRadius: { '2xl': '1.25rem', '3xl': '1.75rem' },
      backgroundImage: {
        'brand-gradient': 'linear-gradient(135deg, #6d8dff 0%, #a06dff 50%, #ff6dd6 100%)',
      },
    },
  },
  plugins: [],
} satisfies Config;
