import { Worker } from 'bullmq';
import { processMergePdf } from './processors/merge-pdf.processor';
import { processCompressImage } from './processors/compress-image.processor';

const connection = { url: process.env.REDIS_URL || 'redis://localhost:6379' } as any;

// One Worker per queue. Concurrency tuned per workload — CPU-bound PDF/image
// work is capped lower than typical IO-bound work to avoid saturating the box.
const pdfWorker = new Worker(
  'pdf-processing',
  async (job) => {
    if (job.name === 'merge-pdf') return processMergePdf(job as any);
    // split-pdf, compress-pdf, watermark-pdf, ocr-pdf, etc. are added here
    // as additional `if (job.name === '...')` branches, each backed by its
    // own processor file following the same shape as merge-pdf.processor.ts.
    throw new Error(`No processor registered for job "${job.name}"`);
  },
  { connection, concurrency: 4 },
);

const imageWorker = new Worker(
  'image-processing',
  async (job) => {
    if (job.name === 'compress-image') return processCompressImage(job as any);
    throw new Error(`No processor registered for job "${job.name}"`);
  },
  { connection, concurrency: 8 },
);

for (const w of [pdfWorker, imageWorker]) {
  w.on('completed', (job) => console.log(`[${w.name}] completed ${job.id}`));
  w.on('failed', (job, err) => console.error(`[${w.name}] failed ${job?.id}:`, err.message));
}

console.log('EditFusion worker started — listening on pdf-processing, image-processing');
