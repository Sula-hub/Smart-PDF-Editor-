import { Job } from 'bullmq';
import { PDFDocument } from 'pdf-lib';
import { PrismaClient } from '@prisma/client';
import { randomUUID } from 'crypto';
import { downloadObject, uploadObject } from '../storage';
import type { MergePdfJobData } from '@editfusion/shared';

const prisma = new PrismaClient();

// Real, working Merge PDF implementation using pdf-lib. This is the pattern
// every other PDF tool processor follows: mark ACTIVE -> do the work,
// reporting progress -> upload result -> mark COMPLETED, with a FAILED
// path that never leaves the DB Job row stuck in an ambiguous state.
export async function processMergePdf(job: Job<MergePdfJobData>) {
  const { jobId, userId, fileKeys } = job.data;

  await prisma.job.update({ where: { id: jobId }, data: { status: 'ACTIVE', startedAt: new Date() } });

  try {
    const merged = await PDFDocument.create();

    for (let i = 0; i < fileKeys.length; i++) {
      const bytes = await downloadObject(fileKeys[i]);
      const src = await PDFDocument.load(bytes);
      const copiedPages = await merged.copyPages(src, src.getPageIndices());
      copiedPages.forEach((p) => merged.addPage(p));

      const progress = Math.round(((i + 1) / fileKeys.length) * 90); // reserve last 10% for upload
      await job.updateProgress(progress);
      await prisma.job.update({ where: { id: jobId }, data: { progress } });
    }

    const outputBytes = await merged.save();
    const outputKey = `outputs/${userId}/${randomUUID()}.pdf`;
    await uploadObject(outputKey, Buffer.from(outputBytes), 'application/pdf');

    const outputFile = await prisma.file.create({
      data: {
        userId,
        originalName: 'merged.pdf',
        mimeType: 'application/pdf',
        sizeBytes: outputBytes.length,
        storageKey: outputKey,
        status: 'READY',
        expiresAt: new Date(Date.now() + Number(process.env.FILE_TTL_MINUTES ?? 60) * 60_000),
      },
    });

    await prisma.job.update({
      where: { id: jobId },
      data: { status: 'COMPLETED', progress: 100, finishedAt: new Date(), outputFileId: outputFile.id },
    });
  } catch (err: any) {
    await prisma.job.update({
      where: { id: jobId },
      data: { status: 'FAILED', errorMessage: err.message, finishedAt: new Date() },
    });
    throw err; // let BullMQ record it as a failed job for retry/inspection too
  }
}
