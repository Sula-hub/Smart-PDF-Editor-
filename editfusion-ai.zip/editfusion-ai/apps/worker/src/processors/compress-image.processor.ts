import { Job } from 'bullmq';
import sharp from 'sharp';
import { PrismaClient } from '@prisma/client';
import { randomUUID } from 'crypto';
import { downloadObject, uploadObject } from '../storage';
import type { CompressImageJobData } from '@editfusion/shared';

const prisma = new PrismaClient();

export async function processCompressImage(job: Job<CompressImageJobData>) {
  const { jobId, userId, fileKey, quality, format } = job.data;

  await prisma.job.update({ where: { id: jobId }, data: { status: 'ACTIVE', startedAt: new Date() } });

  try {
    const input = await downloadObject(fileKey);
    await job.updateProgress(30);

    const targetFormat = format ?? 'jpeg';
    const output = await sharp(input)[targetFormat]({ quality }).toBuffer();
    await job.updateProgress(80);

    const outputKey = `outputs/${userId}/${randomUUID()}.${targetFormat}`;
    await uploadObject(outputKey, output, `image/${targetFormat}`);

    const outputFile = await prisma.file.create({
      data: {
        userId,
        originalName: `compressed.${targetFormat}`,
        mimeType: `image/${targetFormat}`,
        sizeBytes: output.length,
        storageKey: outputKey,
        status: 'READY',
        expiresAt: new Date(Date.now() + Number(process.env.FILE_TTL_MINUTES ?? 60) * 60_000),
      },
    });

    await prisma.job.update({
      where: { id: jobId },
      data: { status: 'COMPLETED', progress: 100, finishedAt: new Date(), outputFileId: outputFile.id },
    });
  } catch (err: any) {
    await prisma.job.update({
      where: { id: jobId },
      data: { status: 'FAILED', errorMessage: err.message, finishedAt: new Date() },
    });
    throw err;
  }
}
